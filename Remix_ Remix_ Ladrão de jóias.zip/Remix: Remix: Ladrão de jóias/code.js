var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["917e8574-d894-443a-9812-0ea260ec141c","960ab8ec-7018-4993-be25-10c12bc72027"],"propsByKey":{"917e8574-d894-443a-9812-0ea260ec141c":{"name":"alienBlue","sourceUrl":null,"frameSize":{"x":69,"y":98},"frameCount":23,"looping":true,"frameDelay":12,"version":"gHlZpdC1HrZOVhH2djGIDsX1vQcmbhMW","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":414,"y":392},"rootRelativePath":"assets/917e8574-d894-443a-9812-0ea260ec141c.png"},"960ab8ec-7018-4993-be25-10c12bc72027":{"name":"diamond","sourceUrl":null,"frameSize":{"x":224,"y":180},"frameCount":18,"looping":true,"frameDelay":12,"version":"Q3zIyszedW8mWHHrcMb25p8QiftjM0G7","categories":["stickers"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":896,"y":900},"rootRelativePath":"assets/960ab8ec-7018-4993-be25-10c12bc72027.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

createEdgeSprites();
var ladrão = createSprite(200,320,30,30)
ladrão.setAnimation("alienBlue")
ladrão.scale=0.6

var diamante = createSprite(375,25,20,20);
diamante.setAnimation("diamond")
diamante.scale=0.2

var laser1=createSprite(400,220,500,5)
laser1.shapeColor="red"

var laser2=createSprite(0,110,200,5)
laser2.shapeColor="red"

var laser3=createSprite(278,0,5,200)
laser3.shapeColor="red"



var laser4=createSprite(358,116,200,5)
laser4.shapeColor="red"



function draw() {
 background ("white")
 
  

 



 if (keyDown("space")){
   playSound("assets/category_loops/show_me_a_hero_middle_loop.mp3",true);
 }
 
   if (ladrão.isTouching(diamante)){
     stopSound("assets/category_loops/show_me_a_hero_middle_loop.mp3");
     
   }
 

  
  
  if (keyDown("up")){


    ladrão.y = ladrão.y-5
  }
  if (keyDown("down")){
   
   
    ladrão.y = ladrão.y+5
  }
  if (keyDown("left")){
  
  
    ladrão.x = ladrão.x-5
  }
  if (keyDown("right")){
  
  
    ladrão.x = ladrão.x+5
  }
 
 if (ladrão.isTouching(diamante)){
textSize(40);
    stroke("red");
    fill("blue")
    text("VOCÊ VENCEU",50,200)
  }
  
  
  
  if (keyDown("space")){
    laser1.velocityY = 3;
    laser1.velocityX = 0;
  
    laser2.velocityY = -3;
    laser2.velocityX = 0;
    
    laser3.velocityY = 0;
    laser3.velocityX = -3;
  
    laser4.velocityY=0
    laser4.velocityX=-3
    
  }
  
  
  if (laser1.isTouching(ladrão) || laser2.isTouching(ladrão) || laser3.isTouching(ladrão)){
    textSize(55);
    stroke("red");
    fill("red")  
    text("VOCÊ PERDEU",0,200)
    stopSound("assets/category_loops/show_me_a_hero_middle_loop.mp3");
    
    
    ladrão.x = 200
    ladrão.y = 360
    
  }
   
  laser1.bounceOff(topEdge)
  laser1.bounceOff(bottomEdge)
  
  laser2.bounceOff(topEdge)
  laser2.bounceOff(bottomEdge)
  
  laser3.bounceOff(leftEdge)
  laser3.bounceOff(rightEdge)
  
  laser4.bounceOff(leftEdge)
  laser4.bounceOff(rightEdge)
ladrão.bounceOff(edges);

if (ladrão.isTouching(laser1||laser2||laser3)){
  ladrão.y=ladrão
}
if (ladrão.isTouching(diamante)){
   laser1.velocityY = 0;
    laser1.velocityX = 0;
  
    laser2.velocityY = 0;
    laser2.velocityX = 0;
    
    laser3.velocityY = 0;
    laser3.velocityX = 0;
  
    laser4.velocityY=0;
    laser4.velocityX=0;
}
drawSprites()
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
